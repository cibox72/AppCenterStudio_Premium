@echo off
powershell.exe -ExecutionPolicy Bypass -File "%~dp0GRU_PHOTOManager2026.ps1"
pause