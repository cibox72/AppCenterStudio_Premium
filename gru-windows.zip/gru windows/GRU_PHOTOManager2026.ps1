# GRU G&L Studio - Versione Windows
Add-Type -AssemblyName System.Windows.Forms

# 1. Seleziona cartella ORIGINALI
$folderBrowser = New-Object System.Windows.Forms.FolderBrowserDialog
$folderBrowser.Description = "1. SELEZIONA: Cartella con TUTTE le foto originali"
$result = $folderBrowser.ShowDialog()
if ($result -ne 'OK') { exit }
$ORIGINALI = $folderBrowser.SelectedPath

# 2. Seleziona cartella DESTINAZIONE
$folderBrowser.Description = "2. SELEZIONA: Dove creare la cartella di lavoro?"
$result = $folderBrowser.ShowDialog()
if ($result -ne 'OK') { exit }
$DESTINAZIONE_BASE = $folderBrowser.SelectedPath

# 3. Seleziona file LISTA NOMI (.txt)
$fileBrowser = New-Object System.Windows.Forms.OpenFileDialog
$fileBrowser.Filter = "File di testo (*.txt)|*.txt"
$fileBrowser.Title = "3. SELEZIONA: File .txt con la lista nomi foto"
$result = $fileBrowser.ShowDialog()
if ($result -ne 'OK') { exit }
$LISTA_FILE = $fileBrowser.FileName

# Crea nome cartella finale
$NOME_CLIENTE = [System.IO.Path]::GetFileNameWithoutExtension($LISTA_FILE) -replace 'selezione_', '' -replace '_', ' '
$CARTELLA_FINALE = Join-Path $DESTINAZIONE_BASE "Scelta_Foto_${NOME_CLIENTE}_Originale"
New-Item -ItemType Directory -Force -Path $CARTELLA_FINALE | Out-Null

# Copia le foto
$TROVATI = 0
$NON_TROVATI = @()
$nomiFoto = Get-Content $LISTA_FILE

foreach ($NOME_FOTO in $nomiFoto) {
    $NOME_PULITO = $NOME_FOTO -replace '\s', ''
    if ([string]::IsNullOrWhiteSpace($NOME_PULITO)) { continue }
    
    $FILE_TROVATO = Get-ChildItem -Path $ORIGINALI -Filter $NOME_PULITO -Recurse -File | Select-Object -First 1
    
    if ($FILE_TROVATO) {
        Copy-Item $FILE_TROVATO.FullName -Destination $CARTELLA_FINALE
        $TROVATI++
    } else {
        $NON_TROVATI += $NOME_PULITO
    }
}

# Messaggio finale
$messaggio = "FATTO!`n`nCopiate $TROVATI foto in:`n$CARTELLA_FINALE"
if ($NON_TROVATI.Count -gt 0) {
    $messaggio += "`n`nNON TROVATE:`n" + ($NON_TROVATI -join "`n")
}

[System.Windows.Forms.MessageBox]::Show($messaggio, "GRU G&L Studio", 'OK', 'Information')